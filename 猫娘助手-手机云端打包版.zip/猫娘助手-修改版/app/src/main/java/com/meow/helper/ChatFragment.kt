package com.meow.helper

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.meow.helper.databinding.FragmentChatBinding
import java.util.concurrent.Executors

/**
 * 猫娘 AI 聊天页（DeepSeek）。
 *
 * 三件事：
 * 1. 管理 API Key / 模型名 / 是否走猫娘改写，存在本地
 * 2. 用 [DeepSeekClient] 发请求，网络调用放在单线程池里，不阻塞 UI
 * 3. AI 回复按配置再过一遍 [MeowTextProcessor]，让口癖和输入改写保持一致
 *
 * 上下文只保留最近 [MAX_TURNS] 轮，避免 token 无限增长。
 */
class ChatFragment : androidx.fragment.app.Fragment(), MainActivity.Refreshable {

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!

    private lateinit var chatAdapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()

    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var sending = false

    /** 令牌用于忽略清空对话或页面重建前发出的过期请求结果。 */
    @Volatile
    private var requestGeneration = 0L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        chatAdapter = ChatAdapter(messages)
        val lm = LinearLayoutManager(requireContext())
        lm.stackFromEnd = true
        binding.chatList.layoutManager = lm
        binding.chatList.adapter = chatAdapter

        binding.sendButton.setOnClickListener { send() }
        binding.aiSaveKeyButton.setOnClickListener { saveKey() }
        binding.aiClearKeyButton.setOnClickListener { clearKey() }
        binding.aiClearChat.setOnClickListener {
            clearChat()
            Toast.makeText(requireContext(), R.string.ai_cleared, Toast.LENGTH_SHORT).show()
        }

        if (messages.isEmpty()) {
            messages.add(ChatMessage(role = ROLE_ASSISTANT, text = getString(R.string.ai_greeting), mine = false))
        }

        loadAiConfig()
    }

    override fun onDestroyView() {
        // 旧请求可以自然结束，但不应再更新已销毁的视图或污染下一次会话。
        requestGeneration++
        sending = false
        super.onDestroyView()
        _binding = null
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    override fun onRefresh() {
        if (_binding == null) return
        loadAiConfig()
    }

    // ------------------------------------------------------------------
    // 配置
    // ------------------------------------------------------------------

    private fun loadAiConfig() {
        val ai = ConfigStore.load(requireContext()).ai
        binding.aiKeyInput.setText(ai.apiKey)
        binding.aiModelInput.setText(ai.model)
        binding.aiMeowifySwitch.isChecked = ai.meowify

        val ready = ai.isReady()
        binding.aiConfigTitle.text = getString(
            if (ready) R.string.ai_ready_title else R.string.ai_not_ready_title
        )
        binding.aiConfigDesc.text = getString(
            if (ready) R.string.ai_ready_desc else R.string.ai_not_ready_desc
        )
        binding.sendButton.isEnabled = ready
    }

    private fun saveKey() {
        val stored = ConfigStore.load(requireContext())
        val key = binding.aiKeyInput.text.toString().trim()
        val model = binding.aiModelInput.text.toString().trim().ifEmpty { "deepseek-chat" }
        ConfigStore.save(
            requireContext(),
            stored.copy(ai = stored.ai.copy(apiKey = key, model = model,
                meowify = binding.aiMeowifySwitch.isChecked))
        )
        loadAiConfig()
        Toast.makeText(requireContext(), R.string.ai_key_saved, Toast.LENGTH_SHORT).show()
    }

    private fun clearKey() {
        val stored = ConfigStore.load(requireContext())
        ConfigStore.save(requireContext(), stored.copy(ai = stored.ai.copy(apiKey = "")))
        binding.aiKeyInput.setText("")
        loadAiConfig()
        Toast.makeText(requireContext(), R.string.ai_key_cleared, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // 收发
    // ------------------------------------------------------------------

    private fun send() {
        if (sending) return

        val text = binding.chatInput.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(requireContext(), R.string.ai_empty_input, Toast.LENGTH_SHORT).show()
            return
        }

        val config = ConfigStore.load(requireContext())
        if (!config.ai.isReady()) {
            Toast.makeText(requireContext(), R.string.ai_need_key, Toast.LENGTH_LONG).show()
            return
        }

        binding.chatInput.setText("")
        messages.add(ChatMessage(role = ROLE_USER, text = text, mine = true))
        chatAdapter.notifyItemInserted(messages.size - 1)

        val thinkingIndex = messages.size
        val requestId = ++requestGeneration
        messages.add(ChatMessage(role = ROLE_ASSISTANT, text = getString(R.string.ai_thinking), mine = false, pending = true))
        chatAdapter.notifyItemInserted(thinkingIndex)
        scrollToBottom()

        sending = true
        binding.sendButton.isEnabled = false

        // 只带最近若干轮上下文
        val history = messages
            .filter { !it.pending }
            .takeLast(MAX_TURNS * 2)
            .map { DeepSeekClient.Message(it.role, it.text) }

        executor.execute {
            val result = DeepSeekClient.chat(config.ai.apiKey, config.ai.model, history)

            val finalText = when (result) {
                is DeepSeekClient.Result.Success -> {
                    // AI 回复也走一遍猫娘改写，保持口癖一致
                    if (config.ai.meowify) MeowTextProcessor.process(result.text, config)
                    else result.text
                }
                is DeepSeekClient.Result.Failure -> result.message
            }

            activity?.runOnUiThread {
                if (_binding == null || requestId != requestGeneration || thinkingIndex !in messages.indices) {
                    return@runOnUiThread
                }
                messages[thinkingIndex] = ChatMessage(
                    role = ROLE_ASSISTANT,
                    text = finalText,
                    mine = false,
                    pending = false,
                    isError = result is DeepSeekClient.Result.Failure
                )
                chatAdapter.notifyItemChanged(thinkingIndex)
                scrollToBottom()
                sending = false
                binding.sendButton.isEnabled = true
            }
        }
    }

    private fun scrollToBottom() {
        if (messages.isNotEmpty()) binding.chatList.smoothScrollToPosition(messages.size - 1)
    }

    /** 清空当前对话，保留猫娘的开场白 */
    fun clearChat() {
        // 使进行中的响应失效，避免异步结果写入已清空的消息列表。
        requestGeneration++
        sending = false
        if (_binding != null) binding.sendButton.isEnabled = ConfigStore.load(requireContext()).ai.isReady()
        messages.clear()
        messages.add(ChatMessage(role = ROLE_ASSISTANT, text = getString(R.string.ai_greeting), mine = false))
        chatAdapter.notifyDataSetChanged()
    }

    companion object {
        const val ROLE_USER = "user"
        const val ROLE_ASSISTANT = "assistant"
        private const val MAX_TURNS = 8
    }
}

/** 一条聊天消息 */
data class ChatMessage(
    val role: String,
    val text: String,
    val mine: Boolean,
    val pending: Boolean = false,
    val isError: Boolean = false
)
