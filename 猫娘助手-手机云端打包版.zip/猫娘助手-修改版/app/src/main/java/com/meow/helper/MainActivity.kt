package com.meow.helper

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AlertDialog
import com.meow.helper.databinding.ActivityMainBinding

/**
 * 猫娘助手主界面：顶部猫耳标题 + 三个 Tab（控制台 / 规则 / 猫娘）。
 *
 * 三个页面各自读写同一份 [MeowConfig]，切换 Tab 时会重新加载，
 * 避免在规则页改了东西、控制台页还显示旧值。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val controlFragment by lazy { ControlFragment() }
    private val rulesFragment by lazy { RulesFragment() }
    private val chatFragment by lazy { ChatFragment() }

    // 只在用户主动打开系统授权页面后使用；返回时恢复控制台，不监控或干预系统页面。
    private var returnToControlOnResume = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            showConsentIfNeeded()
        }

        if (savedInstanceState == null) {
            showFragment(controlFragment)
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_control -> showFragment(controlFragment)
                R.id.nav_rules -> showFragment(rulesFragment)
                R.id.nav_chat -> showFragment(chatFragment)
                else -> return@setOnItemSelectedListener false
            }
            true
        }
    }


    /** 首次启动时透明说明无障碍与 Shizuku 的用途，由用户主动决定是否继续。 */
    private fun showConsentIfNeeded() {
        val prefs = getSharedPreferences("privacy_consent", MODE_PRIVATE)
        if (prefs.getBoolean("consent_decided", false)) return

        AlertDialog.Builder(this)
            .setTitle(R.string.consent_title)
            .setMessage(R.string.consent_message)
            .setCancelable(false)
            .setPositiveButton(R.string.consent_continue) { _, _ ->
                prefs.edit().putBoolean("consent_decided", true)
                    .putBoolean("consent_accepted", true).apply()
                AlertDialog.Builder(this)
                    .setTitle(R.string.consent_next_title)
                    .setMessage(R.string.consent_next_message)
                    .setPositiveButton(R.string.ok, null)
                    .show()
            }
            .setNegativeButton(R.string.consent_decline) { _, _ ->
                prefs.edit().putBoolean("consent_decided", true)
                    .putBoolean("consent_accepted", false).apply()
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        // 用户主动进入系统授权页面并返回后，回到控制台并刷新状态。
        // 不会自动关闭系统设置，也不会阻止用户撤销授权。
        if (returnToControlOnResume) {
            returnToControlOnResume = false
            if (binding.bottomNav.selectedItemId != R.id.nav_control) {
                binding.bottomNav.selectedItemId = R.id.nav_control
            } else {
                showFragment(controlFragment)
            }
        }
        supportFragmentManager.fragments.forEach {
            if (it is Refreshable) it.onRefresh()
        }
    }

    /** 标记用户主动打开系统授权流程；仅在用户返回本应用时恢复控制台。 */
    fun expectReturnToControl() {
        returnToControlOnResume = true
    }

    fun cancelExpectedReturnToControl() {
        returnToControlOnResume = false
    }

    private fun showFragment(target: Fragment) {
        val tx = supportFragmentManager.beginTransaction()
        supportFragmentManager.fragments.forEach { tx.hide(it) }
        if (target.isAdded) {
            tx.show(target)
        } else {
            tx.add(R.id.fragment_container, target)
        }
        tx.commitNowAllowingStateLoss()
        (target as? Refreshable)?.onRefresh()
    }

    /** 页面可见时回调，用于刷新服务状态等动态信息 */
    interface Refreshable {
        fun onRefresh()
    }
}
