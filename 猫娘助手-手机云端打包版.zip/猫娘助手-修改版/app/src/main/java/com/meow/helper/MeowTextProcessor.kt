package com.meow.helper

import kotlin.random.Random

/**
 * 猫娘文本改写核心逻辑（纯函数，无 Android 依赖，可单测）。
 *
 * ## 算法：对原文做单趟扫描
 *
 * 每个位置依次判断三件事，优先级从高到低：
 *
 * 1. **不变词命中** → 原样吐出，整段跳过，且标记「刚才是受保护区」
 * 2. **标点** → 若开启断句加喵、且前一个输出字符不是「喵」、且**不是紧跟在不变词后面**，
 *    则在标点前插入「喵」
 * 3. **替换规则命中** → 吐出替换结果
 *
 * 单趟扫描原文而非反复 replace，带来两个关键性质：
 *
 * - **无级联污染**：替换产物不会被再次扫描。所以「你 → 主人」产出的「人」
 *   不会被「人 → 两脚兽」二次改写成「主两脚兽」。
 * - **幂等**：同一段文本重复处理结果不变。已插入的「喵」会让下一次扫描在
 *   同一标点前看到「前一个字符是喵」而跳过。
 *
 * ## 不变词（保护词）
 *
 * 受保护的区域完全不被改写，**并且会抑制紧跟其后的「喵」插入**。
 * 例如把「本喵们」登记为不变词后，输入「本喵们，」输出仍是「本喵们，」，
 * 而不是「本喵们喵，」。
 */
object MeowTextProcessor {

    /** 需要在其前面加「喵」的标点集合 */
    private val PUNCTUATIONS: Set<Char> = setOf(
        '，', '。', '！', '？', '；', '：', '、', '…',
        ',', '.', '!', '?', ';', ':'
    )

    /**
     * 句末标点：只有打到这里才触发整句改写。
     *
     * 逗号、顿号、分号、冒号这些「句中停顿」**不在**此列——
     * 用户打「你好，」时不动手，等打到「你好，你好。」的句号才一次性处理整句。
     */
    private val SENTENCE_END: Set<Char> = setOf(
        '。', '！', '？', '…', '!', '?', '.'
    )

    /**
     * 完整改写：规则替换 + 加喵 + 末尾颜文字。
     *
     * @param random 随机源（单测时可注入固定种子）
     */
    fun process(text: String, config: MeowConfig, random: Random = Random.Default): String {
        val body = transform(text, config)
        return if (config.addEmoticon && body.isNotEmpty()) {
            body + config.randomEmoticon(random)
        } else {
            body
        }
    }

    /**
     * 只做正文改写（不变词保护 + 规则替换 + 加喵），不追加颜文字。
     * 颜文字的追加 / 剥离由调用方管理，见 [stripTrailingEmoticon]。
     */
    fun transform(text: String, config: MeowConfig): String {
        if (text.isEmpty()) return text

        // 参与匹配的规则：启用且有效，按 from 长度降序（长词优先，避免短词抢匹配）
        val rules = config.activeRules().sortedByDescending { it.from.length }
        // 不变词：去空、去重，按长度降序（长词优先）
        val protectedWords = config.activeProtectedWords().sortedByDescending { it.length }

        val out = StringBuilder(text.length + 32)
        var i = 0
        // 上一个吐出的片段是否为受保护的不变词
        var lastWasProtected = false

        while (i < text.length) {
            // 1. 不变词优先：命中则整段原样保留
            val pw = matchLongest(text, i, protectedWords)
            if (pw != null) {
                out.append(pw)
                i += pw.length
                lastWasProtected = true
                continue
            }

            val c = text[i]

            // 2. 标点前加喵
            if (config.addMeow && c in PUNCTUATIONS && !isNumericContext(text, i)) {
                val prev = if (out.isEmpty()) null else out[out.length - 1]
                if (prev != '喵' && !lastWasProtected) out.append('喵')
            }

            // 3. 替换规则
            val rule = matchLongestRule(text, i, rules)
            if (rule != null) {
                out.append(rule.to)
                i += rule.from.length
                lastWasProtected = false
                continue
            }

            out.append(c)
            i++
            lastWasProtected = false
        }

        return out.toString()
    }

    /** 在 [text] 的 [index] 处匹配最长的候选词，无命中返回 null */
    private fun matchLongest(text: String, index: Int, candidates: List<String>): String? {
        for (cand in candidates) {
            if (cand.isNotEmpty() && text.startsWith(cand, index)) return cand
        }
        return null
    }

    private fun matchLongestRule(text: String, index: Int, rules: List<MeowRule>): MeowRule? {
        for (rule in rules) {
            if (text.startsWith(rule.from, index)) return rule
        }
        return null
    }

    /**
     * 在每个标点前插入「喵」（不考虑不变词与替换规则的独立入口，主要给单测用）。
     */
    fun insertMeow(text: String): String {
        if (text.isEmpty()) return text
        val sb = StringBuilder(text.length + 16)
        for (i in text.indices) {
            val c = text[i]
            if (c in PUNCTUATIONS && !isNumericContext(text, i)) {
                val prev = if (sb.isEmpty()) null else sb[sb.length - 1]
                if (prev != '喵') sb.append('喵')
            }
            sb.append(c)
        }
        return sb.toString()
    }

    /** 半角 `.` / `:` 前后都是数字时，认为是小数或时间，不算标点 */
    private fun isNumericContext(text: String, index: Int): Boolean {
        val c = text[index]
        if (c != '.' && c != ':') return false
        val prev = text.getOrNull(index - 1)
        val next = text.getOrNull(index + 1)
        return prev != null && prev.isDigit() && next != null && next.isDigit()
    }

    /**
     * 结尾是否落在一个标点上（供「标点触发」这类更激进的档位使用）。
     */
    fun endsWithPunctuation(text: String): Boolean {
        val trimmed = text.trimEnd()
        if (trimmed.isEmpty()) return false
        val lastIndex = trimmed.length - 1
        return trimmed[lastIndex] in PUNCTUATIONS && !isNumericContext(trimmed, lastIndex)
    }

    /**
     * 结尾是否为句末标点（。！？… 及半角 ! ? .）——「句末触发」模式的触发条件。
     *
     * 半角 `.` 同样走数字语境保护，避免输入 `3.14` 时被当成句子结束。
     */
    fun endsWithSentenceEnd(text: String): Boolean {
        val trimmed = text.trimEnd()
        if (trimmed.isEmpty()) return false
        val lastIndex = trimmed.length - 1
        val last = trimmed[lastIndex]
        return last in SENTENCE_END && !isNumericContext(trimmed, lastIndex)
    }

    /**
     * 从文本中剥掉我们上次追加的那个颜文字。
     *
     * 用「最后一次出现的位置」而不是「结尾匹配」：用户在颜文字后面又接着打字时，
     * 颜文字就不在结尾了，此时把它摘掉、稍后重新追加到新的末尾，
     * 就能保持「颜文字永远跟在消息最后」的体验。
     */
    fun stripTrailingEmoticon(text: String, emoticon: String?): String {
        if (emoticon.isNullOrEmpty()) return text
        val index = text.lastIndexOf(emoticon)
        if (index < 0) return text
        return text.removeRange(index, index + emoticon.length)
    }
}
