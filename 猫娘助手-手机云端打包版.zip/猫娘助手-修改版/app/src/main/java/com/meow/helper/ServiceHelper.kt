package com.meow.helper

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils

/**
 * 无障碍服务状态查询与跳转。
 *
 * 说明：Android 不允许 App 自己打开/关闭无障碍服务（那是系统安全边界），
 * 所以「一键开关」实际是两层：
 * - **系统层**：无障碍服务是否被授权，只能引导用户去系统设置里打开
 * - **应用层**：[MeowConfig.enabled] 总开关，App 内可以真正一键切换，
 *   关掉后服务即使仍在运行也完全不碰输入框
 *
 * 界面上把两层合并成一个体验：已授权时大开关直接改 enabled（真一键）；
 * 未授权时按钮引导去系统设置。
 */
object ServiceHelper {

    /** 无障碍服务是否已在系统设置里被授权 */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val expected = ComponentName(context, MeowAccessibilityService::class.java)
        val flatExpected = expected.flattenToString()

        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        if (TextUtils.isEmpty(enabledServices)) return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            val name = splitter.next()
            if (name.equals(flatExpected, ignoreCase = true)) return true
            // 兼容部分 ROM 只写类名的情况
            if (name.equals(expected.className, ignoreCase = true)) return true
        }
        return false
    }

    /** 服务进程是否真的活着（已授权且已被系统绑定） */
    fun isServiceRunning(): Boolean = MeowAccessibilityService.isRunning()

    /** 打开系统无障碍设置页 */
    fun openAccessibilitySettings(context: Context): Boolean {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
