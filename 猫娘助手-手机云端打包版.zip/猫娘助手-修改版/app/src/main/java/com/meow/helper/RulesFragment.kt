package com.meow.helper

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.meow.helper.databinding.FragmentRulesBinding

/**
 * 规则页：替换规则的增删开关 + 不变词的增删。
 *
 * 本页所有改动都先落在内存里的 [draftRules] / [draftWords]，
 * 点「保存设置」才写盘——和无障碍服务「下次触发时自动加载」的约定一致。
 */
class RulesFragment : androidx.fragment.app.Fragment(), MainActivity.Refreshable {

    private var _binding: FragmentRulesBinding? = null
    private val binding get() = _binding!!

    private lateinit var ruleAdapter: RuleAdapter
    private lateinit var wordAdapter: ProtectedWordAdapter

    private var draftRules: MutableList<MeowRule> = mutableListOf()
    private var draftWords: MutableList<String> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRulesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        ruleAdapter = RuleAdapter(
            onToggle = { position, enabled ->
                draftRules[position] = draftRules[position].copy(enabled = enabled)
                ruleAdapter.notifyItemChanged(position)
            },
            onDelete = { position -> confirmDeleteRule(position) }
        )
        wordAdapter = ProtectedWordAdapter(
            onDelete = { position ->
                draftWords.removeAt(position)
                wordAdapter.notifyItemRemoved(position)
                wordAdapter.notifyItemRangeChanged(position, draftWords.size)
            }
        )

        binding.ruleList.layoutManager = LinearLayoutManager(requireContext())
        binding.ruleList.adapter = ruleAdapter
        binding.protectedList.layoutManager = LinearLayoutManager(requireContext())
        binding.protectedList.adapter = wordAdapter

        binding.addRuleButton.setOnClickListener { showAddRuleDialog() }
        binding.addProtectedButton.setOnClickListener { showAddProtectedDialog() }
        binding.saveButton.setOnClickListener { save() }
        binding.testButton.setOnClickListener { TestDialog.show(requireContext(), ::currentConfig) }

        loadConfig()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onRefresh() {
        if (_binding == null) return
        loadConfig()
    }

    // ------------------------------------------------------------------

    private fun loadConfig() {
        val config = ConfigStore.load(requireContext())
        draftRules = config.rules.toMutableList()
        draftWords = config.activeProtectedWords().toMutableList()
        ruleAdapter.submit(draftRules)
        wordAdapter.submit(draftWords)
    }

    private fun currentConfig(): MeowConfig {
        val stored = ConfigStore.load(requireContext())
        return stored.copy(rules = draftRules.toList(), protectedWords = draftWords.toList())
    }

    private fun save() {
        val stored = ConfigStore.load(requireContext())
        ConfigStore.save(
            requireContext(),
            stored.copy(
                rules = draftRules.toList(),
                protectedWords = draftWords.toList()
            )
        )
        Toast.makeText(requireContext(), R.string.toast_saved, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // 添加替换规则
    // ------------------------------------------------------------------

    private fun showAddRuleDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_rule, null)
        val fromInput = view.findViewById<EditText>(R.id.rule_from_input)
        val toInput = view.findViewById<EditText>(R.id.rule_to_input)

        AlertDialog.Builder(requireContext())
            .setTitle(R.string.rule_add)
            .setView(view)
            .setPositiveButton(R.string.ok) { _, _ ->
                val from = fromInput.text.toString().trim()
                val to = toInput.text.toString()

                if (from.isEmpty()) {
                    toast(R.string.rule_empty_from)
                    return@setPositiveButton
                }
                if (draftRules.any { it.from == from && it.builtIn == false }) {
                    toast(R.string.rule_duplicate)
                    return@setPositiveButton
                }

                // 用户规则插到最前面，优先级高于内置规则
                draftRules.add(0, MeowRule(from, to, enabled = true, builtIn = false))
                ruleAdapter.submit(draftRules)
                toast(R.string.rule_added)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteRule(position: Int) {
        val rule = draftRules.getOrNull(position) ?: return
        if (rule.builtIn) {
            toast(R.string.rule_builtin_undeletable)
            return
        }
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.delete)
            .setMessage("${rule.from} → ${rule.to}")
            .setPositiveButton(R.string.delete) { _, _ ->
                draftRules.removeAt(position)
                ruleAdapter.submit(draftRules)
                toast(R.string.rule_deleted)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ------------------------------------------------------------------
    // 添加不变词
    // ------------------------------------------------------------------

    private fun showAddProtectedDialog() {
        val view = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_add_protected, null)
        val input = view.findViewById<EditText>(R.id.word_input)

        AlertDialog.Builder(requireContext())
            .setTitle(R.string.protected_add)
            .setView(view)
            .setPositiveButton(R.string.ok) { _, _ ->
                val word = input.text.toString().trim()
                if (word.isEmpty()) {
                    toast(R.string.protected_empty)
                    return@setPositiveButton
                }
                if (draftWords.any { it == word }) {
                    toast(R.string.protected_duplicate)
                    return@setPositiveButton
                }
                draftWords.add(word)
                wordAdapter.submit(draftWords)
                toast(R.string.protected_added)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(resId: Int) =
        Toast.makeText(requireContext(), resId, Toast.LENGTH_SHORT).show()
}
