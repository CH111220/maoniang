package com.meow.helper

import kotlin.random.Random

/**
 * 猫娘助手的配置项。
 *
 * 本类刻意不引入任何 Android 依赖，方便在 JVM 单元测试里直接构造与验证。
 * 持久化（SharedPreferences）相关逻辑见 [ConfigStore]。
 *
 * @param sentenceEndTrigger 处理模式：true = 句末触发，false = 实时处理
 * @param enabled            总开关：false 时无障碍服务完全不改写（一键关闭）
 * @param addMeow            断句加喵
 * @param addEmoticon        末尾追加随机颜文字
 * @param rules              替换规则表（内置 + 用户自定义）
 * @param protectedWords     不变词：这些片段完全不改写，且抑制紧跟其后的「喵」
 * @param customEmoticons    自定义颜文字库；为空时用内置库
 * @param ai                 DeepSeek 猫娘 AI 的配置
 */
data class MeowConfig(
    val sentenceEndTrigger: Boolean = true,
    val enabled: Boolean = true,
    val addMeow: Boolean = true,
    val addEmoticon: Boolean = true,
    val rules: List<MeowRule> = MeowRule.defaults(),
    val protectedWords: List<String> = MeowRule.defaultProtectedWords(),
    val customEmoticons: List<String> = emptyList(),
    val ai: AiConfig = AiConfig()
) {

    /** 当前生效的替换规则（已启用、from 非空、且不是自己换自己） */
    fun activeRules(): List<MeowRule> = rules.filter { it.isActive() }

    /** 当前生效的不变词（去空白、去重） */
    fun activeProtectedWords(): List<String> =
        protectedWords.map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    /** 当前生效的颜文字候选池 */
    fun emoticonPool(): List<String> {
        val source = if (customEmoticons.isNotEmpty()) customEmoticons else BUILT_IN_EMOTICONS
        return source.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
            .ifEmpty { BUILT_IN_EMOTICONS }
    }

    /** 随机取一个颜文字 */
    fun randomEmoticon(random: Random = Random.Default): String {
        val pool = emoticonPool()
        return pool[random.nextInt(pool.size)]
    }

    /**
     * 把内置规则合并进来：
     * - 用户关掉过的内置规则保持关闭状态
     * - 新增版本的内置规则自动补上
     * - 用户自定义规则永远排在前面（优先级更高）
     */
    fun withMergedBuiltIns(): MeowConfig {
        val existing = rules.associateBy { it.from to it.builtIn }
        val mergedBuiltIns = MeowRule.defaults().map { def ->
            existing[def.from to true]?.copy(to = def.to) ?: def
        }
        val userRules = rules.filter { !it.builtIn }
        return copy(rules = userRules + mergedBuiltIns)
    }

    companion object {
        /** 内置猫咪颜文字库 */
        val BUILT_IN_EMOTICONS: List<String> = listOf(
            "❍⩊❍",
            "(=^･ω･^=)",
            "(=^w^=)",
            "ฅ^•ﻌ•^ฅ",
            "(=①ω①=)",
            "ฅ(•ㅅ•)ฅ",
            "(=^-ω-^=)",
            "(ΦωΦ)",
            "ฅ^••^ฅ",
            "(=^‥^=)",
            "(=ↀωↀ=)",
            "(＾• ω •＾)",
            "(=｀ω´=)",
            "ฅ(=・ω・=)ฅ",
            "(^･o･^)",
            "(=ＴェＴ=)",
            "ฅ(＾・ω・＾ฅ)",
            "(=^-ω-^=)ノ",
            "(๑>ᴗ<๑)",
            "₍^·͈༝ ·͈^₎◞ ̑ ̑"
        )
    }
}

/**
 * DeepSeek 猫娘 AI 配置。
 *
 * @param apiKey     用户的 DeepSeek API Key，留空则 AI 功能不可用
 * @param model      模型名，默认 deepseek-chat
 * @param meowify    AI 回复是否也走一遍猫娘改写（加喵 / 替换 / 颜文字）
 */
data class AiConfig(
    val apiKey: String = "",
    val model: String = "deepseek-chat",
    val meowify: Boolean = true
) {
    fun isReady(): Boolean = apiKey.isNotBlank()
}
