package com.meow.helper

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * 配置的本地持久化。
 *
 * 无障碍服务每次触发时都会重新 [load] 一次，因此界面上改完设置后，
 * 下一次输入就会自动生效，不需要重启服务。
 *
 * 规则表与不变词用 JSON 存储，方便支持任意数量的用户自定义条目。
 */
object ConfigStore {

    private const val PREFS_NAME = "meow_helper_config"

    private const val KEY_ENABLED = "enabled"
    private const val KEY_SENTENCE_END_TRIGGER = "sentence_end_trigger"
    private const val KEY_ADD_MEOW = "add_meow"
    private const val KEY_ADD_EMOTICON = "add_emoticon"
    private const val KEY_CUSTOM_EMOTICONS = "custom_emoticons"
    private const val KEY_RULES = "rules_json"
    private const val KEY_PROTECTED = "protected_words_json"

    private const val KEY_AI_API_KEY = "ai_api_key"
    private const val KEY_AI_MODEL = "ai_model"
    private const val KEY_AI_MEOWIFY = "ai_meowify"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(context: Context): MeowConfig {
        val p = prefs(context)

        val customEmoticons = p.getString(KEY_CUSTOM_EMOTICONS, "")
            ?.split('\n')
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()

        val storedApiKey = p.getString(KEY_AI_API_KEY, "").orEmpty()
        val apiKey = if (storedApiKey.startsWith(ApiKeyVault.PREFIX)) {
            // 加密值无法解密时按空值处理，避免把密文当作 API Key 发送。
            ApiKeyVault.decrypt(storedApiKey).orEmpty()
        } else {
            // 兼容旧版本：首次读取旧明文 Key 时尽力迁移到 Android Keystore 加密存储。
            if (storedApiKey.isNotBlank()) {
                ApiKeyVault.encrypt(storedApiKey)?.let { encrypted ->
                    p.edit().putString(KEY_AI_API_KEY, encrypted).apply()
                }
            }
            storedApiKey
        }

        val config = MeowConfig(
            sentenceEndTrigger = p.getBoolean(KEY_SENTENCE_END_TRIGGER, true),
            enabled = p.getBoolean(KEY_ENABLED, true),
            addMeow = p.getBoolean(KEY_ADD_MEOW, true),
            addEmoticon = p.getBoolean(KEY_ADD_EMOTICON, true),
            rules = readRules(p),
            protectedWords = readProtectedWords(p),
            customEmoticons = customEmoticons,
            ai = AiConfig(
                apiKey = apiKey,
                model = p.getString(KEY_AI_MODEL, "deepseek-chat")?.takeIf { it.isNotBlank() }
                    ?: "deepseek-chat",
                meowify = p.getBoolean(KEY_AI_MEOWIFY, true)
            )
        )

        // 版本升级后自动补齐新增的内置规则，同时保留用户对旧规则的开关选择
        return config.withMergedBuiltIns()
    }

    fun save(context: Context, config: MeowConfig) {
        val editor = prefs(context).edit()
            .putBoolean(KEY_ENABLED, config.enabled)
            .putBoolean(KEY_SENTENCE_END_TRIGGER, config.sentenceEndTrigger)
            .putBoolean(KEY_ADD_MEOW, config.addMeow)
            .putBoolean(KEY_ADD_EMOTICON, config.addEmoticon)
            .putString(KEY_CUSTOM_EMOTICONS, config.customEmoticons.joinToString("\n"))
            .putString(KEY_RULES, writeRules(config.rules))
            .putString(KEY_PROTECTED, writeProtectedWords(config.protectedWords))
            .putString(KEY_AI_MODEL, config.ai.model)
            .putBoolean(KEY_AI_MEOWIFY, config.ai.meowify)

        if (config.ai.apiKey.isBlank()) {
            editor.putString(KEY_AI_API_KEY, "")
        } else {
            // 如果系统 Keystore 暂时不可用，不要用空值覆盖用户之前保存的密钥。
            ApiKeyVault.encrypt(config.ai.apiKey)?.let { editor.putString(KEY_AI_API_KEY, it) }
        }
        editor.apply()
    }

    // ------------------------------------------------------------------
    // 规则表 JSON
    // ------------------------------------------------------------------

    private fun readRules(p: SharedPreferences): List<MeowRule> {
        val raw = p.getString(KEY_RULES, null) ?: return MeowRule.defaults()
        return try {
            val arr = JSONArray(raw)
            val list = (0 until arr.length()).mapNotNull { idx ->
                val o = arr.optJSONObject(idx) ?: return@mapNotNull null
                val from = o.optString("from", "")
                if (from.isEmpty()) return@mapNotNull null
                MeowRule(
                    from = from,
                    to = o.optString("to", ""),
                    enabled = o.optBoolean("enabled", true),
                    builtIn = o.optBoolean("builtIn", false)
                )
            }
            // 存过但被清空的情况，回落到默认
            if (list.isEmpty()) MeowRule.defaults() else list
        } catch (e: Exception) {
            MeowRule.defaults()
        }
    }

    private fun writeRules(rules: List<MeowRule>): String {
        val arr = JSONArray()
        rules.forEach { r ->
            arr.put(
                JSONObject()
                    .put("from", r.from)
                    .put("to", r.to)
                    .put("enabled", r.enabled)
                    .put("builtIn", r.builtIn)
            )
        }
        return arr.toString()
    }

    // ------------------------------------------------------------------
    // 不变词 JSON
    // ------------------------------------------------------------------

    private fun readProtectedWords(p: SharedPreferences): List<String> {
        val raw = p.getString(KEY_PROTECTED, null) ?: return MeowRule.defaultProtectedWords()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { arr.opt(it)?.toString()?.trim() }
                .filter { it.isNotEmpty() }
        } catch (e: Exception) {
            MeowRule.defaultProtectedWords()
        }
    }

    private fun writeProtectedWords(words: List<String>): String {
        val arr = JSONArray()
        words.map { it.trim() }.filter { it.isNotEmpty() }.forEach { arr.put(it) }
        return arr.toString()
    }
}
