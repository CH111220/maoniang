package com.meow.helper

/**
 * 一条替换规则：把 [from] 换成 [to]。
 *
 * @param enabled  是否启用
 * @param builtIn  是否为内置规则（内置规则不可删除，只能开关；用户规则可删除）
 */
data class MeowRule(
    val from: String,
    val to: String,
    val enabled: Boolean = true,
    val builtIn: Boolean = false
) {
    /** 规则是否可参与匹配：启用、且 from 非空、且不是自己换自己 */
    fun isActive(): Boolean = enabled && from.isNotEmpty() && from != to

    companion object {
        /**
         * 内置规则表。
         *
         * 注意顺序即优先级：同一位置能匹配多条时，靠前的胜出。
         * 「我 -> 本喵」排在「人 -> 两脚兽」前面并不影响结果，
         * 因为改写是对**原文**做单趟扫描，替换产物不会被再次扫描，
         * 所以「你 -> 主人」产出的「人」不会被二次换成「两脚兽」。
         */
        fun defaults(): List<MeowRule> = listOf(
            MeowRule("我", "本喵", enabled = true, builtIn = true),
            MeowRule("你", "主人", enabled = true, builtIn = true),
            MeowRule("人", "两脚兽", enabled = true, builtIn = true),
            MeowRule("了", "惹", enabled = true, builtIn = true)
        )

        /**
         * 内置不变词：保护替换规则的**输出产物**不被下一轮重复改写。
         *
         * 这是幂等性的关键。例如「你好了。」第一次改写成「主人好惹喵。」，
         * 第二次处理时如果「主人」里的「人」再被换成「两脚兽」，就会变成
         * 「主两脚兽好惹喵。」——彻底坏掉。把产物登记为不变词即可避免。
         */
        fun defaultProtectedWords(): List<String> = listOf("本喵", "主人", "两脚兽")
    }
}
