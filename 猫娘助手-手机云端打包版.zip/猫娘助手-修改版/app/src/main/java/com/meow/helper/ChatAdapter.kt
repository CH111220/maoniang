package com.meow.helper

import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.meow.helper.databinding.ItemChatBinding

/**
 * 聊天气泡列表。
 *
 * 主人发的消息靠右、粉底白字；猫娘的回复靠左、白底粉边。
 * 「思考中」和错误回复用不同颜色区分。
 */
class ChatAdapter(
    private val items: List<ChatMessage>
) : RecyclerView.Adapter<ChatAdapter.Holder>() {

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemChatBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(items[position])
    }

    class Holder(private val binding: ItemChatBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private val row: LinearLayout = binding.bubbleRow
        private val bubble: TextView = binding.bubbleText

        fun bind(msg: ChatMessage) {
            val ctx = itemView.context

            row.gravity = if (msg.mine) Gravity.END else Gravity.START
            bubble.setBackgroundResource(
                if (msg.mine) R.drawable.bg_bubble_user else R.drawable.bg_bubble_ai
            )
            bubble.text = msg.text

            val colorRes = when {
                msg.mine -> R.color.text_on_pink
                msg.pending -> R.color.text_hint
                msg.isError -> R.color.danger
                else -> R.color.text_main
            }
            bubble.setTextColor(ctx.getColor(colorRes))

            // 行内边距：自己发的靠右留白，猫娘的靠左留白
            val pad = (ctx.resources.displayMetrics.density * 6).toInt()
            row.setPadding(
                if (msg.mine) pad * 6 else pad,
                0,
                if (msg.mine) pad else pad * 6,
                0
            )
        }
    }
}
