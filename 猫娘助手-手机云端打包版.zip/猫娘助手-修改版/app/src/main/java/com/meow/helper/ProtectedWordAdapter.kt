package com.meow.helper

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.meow.helper.databinding.ItemProtectedBinding

/**
 * 不变词列表。
 *
 * 内置不变词（本喵 / 主人 / 两脚兽）会打上标签提示——它们是用来保护替换结果、
 * 维持幂等性的，删掉可能导致重复改写。但仍然允许删除，只在文案上提醒。
 */
class ProtectedWordAdapter(
    private val onDelete: (position: Int) -> Unit
) : RecyclerView.Adapter<ProtectedWordAdapter.Holder>() {

    private val items: MutableList<String> = mutableListOf()

    /** 内置不变词集合，用于打标签 */
    private val builtIns: Set<String> = MeowRule.defaultProtectedWords().toSet()

    fun submit(list: List<String>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemProtectedBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(items[position])
    }

    inner class Holder(private val binding: ItemProtectedBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private val wordText: TextView = binding.wordText
        private val wordTag: TextView = binding.wordTag
        private val wordDelete: ImageButton = binding.wordDelete

        fun bind(word: String) {
            val ctx = itemView.context
            wordText.text = word

            val isBuiltIn = word in builtIns
            wordTag.text = ctx.getString(
                if (isBuiltIn) R.string.rule_builtin_tag else R.string.rule_user_tag
            )
            wordTag.setBackgroundResource(
                if (isBuiltIn) R.drawable.bg_chip_lavender else R.drawable.bg_chip_pink
            )
            wordTag.setTextColor(
                ctx.getColor(if (isBuiltIn) R.color.lavender_deep else R.color.pink_deep)
            )

            wordDelete.setOnClickListener {
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onDelete(pos)
            }
        }
    }
}
