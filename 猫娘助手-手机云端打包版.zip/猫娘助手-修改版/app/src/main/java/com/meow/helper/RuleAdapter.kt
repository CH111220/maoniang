package com.meow.helper

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.meow.helper.databinding.ItemRuleBinding

/**
 * 替换规则列表。
 *
 * 每行展示「原文 → 替换成」，右侧是启用开关和删除按钮。
 * 内置规则只显示标签、禁用删除按钮（只能关开关，不能删）。
 */
class RuleAdapter(
    private val onToggle: (position: Int, enabled: Boolean) -> Unit,
    private val onDelete: (position: Int) -> Unit
) : RecyclerView.Adapter<RuleAdapter.Holder>() {

    private val items: MutableList<MeowRule> = mutableListOf()

    fun submit(list: List<MeowRule>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemRuleBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(items[position], position)
    }

    inner class Holder(private val binding: ItemRuleBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private val ruleText: TextView = binding.ruleText
        private val ruleTag: TextView = binding.ruleTag
        private val ruleState: TextView = binding.ruleState
        private val ruleSwitch: MaterialSwitch = binding.ruleSwitch
        private val ruleDelete: ImageButton = binding.ruleDelete

        fun bind(rule: MeowRule, position: Int) {
            val ctx = itemView.context

            ruleText.text = if (rule.to.isEmpty()) {
                "${rule.from} → （删除）"
            } else {
                "${rule.from} → ${rule.to}"
            }

            ruleTag.text = ctx.getString(
                if (rule.builtIn) R.string.rule_builtin_tag else R.string.rule_user_tag
            )
            ruleTag.setBackgroundResource(
                if (rule.builtIn) R.drawable.bg_chip_lavender else R.drawable.bg_chip_pink
            )
            ruleTag.setTextColor(
                ctx.getColor(if (rule.builtIn) R.color.lavender_deep else R.color.pink_deep)
            )

            ruleState.text = ctx.getString(
                if (rule.enabled) R.string.rule_state_on else R.string.rule_state_off
            )
            ruleState.setTextColor(
                ctx.getColor(if (rule.enabled) R.color.mint else R.color.text_hint)
            )

            // 先摘掉监听再设值，避免 submit 时误触发回调
            ruleSwitch.setOnCheckedChangeListener(null)
            ruleSwitch.isChecked = rule.enabled
            ruleSwitch.setOnCheckedChangeListener { _, checked ->
                ruleState.text = ctx.getString(
                    if (checked) R.string.rule_state_on else R.string.rule_state_off
                )
                ruleState.setTextColor(
                    ctx.getColor(if (checked) R.color.mint else R.color.text_hint)
                )
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onToggle(pos, checked)
            }

            ruleDelete.visibility = if (rule.builtIn) View.INVISIBLE else View.VISIBLE
            ruleDelete.setOnClickListener {
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onDelete(pos)
            }
        }
    }
}
