package com.meow.helper

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 猫娘助手的无障碍服务。
 *
 * 工作原理：监听输入框的文本变化事件 -> 读取当前文本 -> 用 [MeowTextProcessor] 改写
 * -> 通过 ACTION_SET_TEXT 写回输入框。
 *
 * 几个关键防呆设计：
 * - **一键总开关**：[MeowConfig.enabled] 为 false 时完全不改写，并清掉历史状态，
 *   不需要用户去系统设置里关权限。
 * - **自写回环**：写回文本会再触发一次 TEXT_CHANGED，用 [lastOutput] 比对拦掉。
 * - **幂等**：改写算法本身幂等（不变词保护替换产物 + 已有「喵」不重复插），
 *   即使重复处理也不会叠成「喵喵喵」或把「主人」拆成「主两脚兽」。
 * - **颜文字跟随**：每次改写前先把上次追加的颜文字摘掉，改写完再追加到新的末尾，
 *   保证用户继续打字时颜文字始终跟在消息最后。
 * - **密码框跳过**：[AccessibilityNodeInfo.isPassword] 为真时绝不改写。
 * - **本应用跳过**：在自己界面里不生效，避免测试框被反复改写。
 */
class MeowAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var pendingTask: Runnable? = null

    /** 上一次由本服务写入的文本，用于识别并丢弃自己触发的事件 */
    private var lastOutput: String? = null

    /** 上一次追加的颜文字，改写前需要先把它摘掉 */
    private var lastEmoticon: String? = null

    /** 正在写回的标记，配合 lastOutput 双重保险 */
    @Volatile
    private var selfWriting = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // 切换界面 / 切换输入框，重置状态，避免把旧输入框的颜文字带到新框里
                resetState()
            }

            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                // 不在自己应用里动手，防止测试输入框被反复改写
                if (event.packageName == packageName) return
                scheduleProcess(event)
            }
        }
    }

    override fun onInterrupt() {
        cancelPending()
    }

    override fun onDestroy() {
        cancelPending()
        if (instance === this) instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // 调度
    // ------------------------------------------------------------------

    /**
     * 事件到达后先取出文本判定是否需要处理，再决定是否延迟执行。
     *
     * 标点触发模式下只有结尾落在标点时才动手，天然稀疏，直接执行；
     * 实时模式下每个字符都会触发，加一点防抖合并连续按键。
     */
    private fun scheduleProcess(event: AccessibilityEvent) {
        val node = findEditableNode(event) ?: return
        val raw = node.text?.toString().orEmpty()

        // 自己写回引发的回声事件
        if (selfWriting) return
        if (raw.isNotEmpty() && raw == lastOutput) return

        val config = ConfigStore.load(this)

        // 一键总开关：关闭时完全不改写，并清掉历史状态
        if (!config.enabled) {
            if (lastOutput != null || lastEmoticon != null) resetState()
            return
        }

        if (config.sentenceEndTrigger && !MeowTextProcessor.endsWithSentenceEnd(raw)) {
            // 句末触发模式下，没打到句号/叹号/问号/省略号就先不动，
            // 逗号之类的句中停顿会被跳过，等整句打完再一次性处理
            return
        }

        cancelPending()
        val task = Runnable { processNode(node, raw, config) }
        pendingTask = task
        // 实时模式做 60ms 防抖；句末触发模式立即执行，保证手感
        val delay = if (config.sentenceEndTrigger) 0L else DEBOUNCE_REALTIME_MS
        handler.postDelayed(task, delay)
    }

    private fun cancelPending() {
        pendingTask?.let { handler.removeCallbacks(it) }
        pendingTask = null
    }

    // ------------------------------------------------------------------
    // 核心改写
    // ------------------------------------------------------------------

    private fun processNode(node: AccessibilityNodeInfo, rawAtSchedule: String, config: MeowConfig) {
        pendingTask = null

        // 防抖期间用户可能又打了字，这里重新读一次最新文本
        val raw = node.text?.toString() ?: rawAtSchedule
        if (selfWriting) return
        if (raw.isNotEmpty() && raw == lastOutput) return

        // 句末触发模式下再确认一次：最新文本仍然以句末标点结尾才处理
        if (config.sentenceEndTrigger && !MeowTextProcessor.endsWithSentenceEnd(raw)) return

        // 1. 摘掉上次追加的颜文字
        val base = MeowTextProcessor.stripTrailingEmoticon(raw, lastEmoticon)

        // 2. 人称替换 + 加喵
        val transformed = MeowTextProcessor.transform(base, config)

        // 3. 末尾追加新的随机颜文字
        val emoticon = if (config.addEmoticon && transformed.isNotEmpty()) config.randomEmoticon() else null
        val finalText = if (emoticon != null) transformed + emoticon else transformed

        // 没有实际变化就别写，避免无谓的光标跳动
        if (finalText == raw) {
            lastOutput = raw
            lastEmoticon = emoticon
            return
        }

        writeText(node, finalText)
        lastOutput = finalText
        lastEmoticon = emoticon
    }

    private fun writeText(node: AccessibilityNodeInfo, text: String) {
        selfWriting = true
        try {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

            // 多数输入法在 SET_TEXT 后会把光标放到末尾；这里显式再定位一次，
            // 减少个别 ROM 上光标跳到开头的情况。
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, text.length)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, text.length)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } catch (_: Exception) {
            // 个别控件不支持 SET_TEXT，忽略即可，不影响后续输入
        } finally {
            handler.postDelayed({ selfWriting = false }, SELF_WRITE_GUARD_MS)
        }
    }

    private fun resetState() {
        cancelPending()
        lastOutput = null
        lastEmoticon = null
        selfWriting = false
    }

    // ------------------------------------------------------------------
    // 节点定位
    // ------------------------------------------------------------------

    private fun findEditableNode(event: AccessibilityEvent): AccessibilityNodeInfo? {
        event.source?.let { src ->
            if (isEditable(src)) return src
            src.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let {
                if (isEditable(it)) return it
            }
        }
        try {
            rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let {
                if (isEditable(it)) return it
            }
        } catch (_: Exception) {
        }
        return null
    }

    /** 是否是我们愿意改写的输入框（密码框一律排除） */
    private fun isEditable(node: AccessibilityNodeInfo): Boolean {
        if (node.isPassword) return false
        if (node.isEditable) return true
        val className = node.className?.toString() ?: return false
        return EDITABLE_CLASS_HINTS.any { className.contains(it, ignoreCase = true) }
    }

    companion object {
        /** 供界面查询服务是否在运行 */
        @Volatile
        var instance: MeowAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null

        private const val DEBOUNCE_REALTIME_MS = 60L
        private const val SELF_WRITE_GUARD_MS = 120L

        private val EDITABLE_CLASS_HINTS = listOf(
            "EditText",
            "TextInputEditText",
            "AutoCompleteTextView",
            "MultiAutoCompleteTextView",
            "android.webkit.WebView"
        )
    }
}
