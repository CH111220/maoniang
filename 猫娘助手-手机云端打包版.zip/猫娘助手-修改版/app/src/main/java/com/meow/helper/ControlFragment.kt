package com.meow.helper

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import androidx.appcompat.app.AlertDialog
import com.meow.helper.databinding.FragmentControlBinding

/**
 * 控制台页：服务状态、一键开关、处理模式、功能开关、颜文字库、保存与测试。
 */
class ControlFragment : androidx.fragment.app.Fragment(), MainActivity.Refreshable {

    private var _binding: FragmentControlBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentControlBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.serviceButton.setOnClickListener { onServiceButtonClick() }
        binding.masterSwitch.setOnCheckedChangeListener { _, checked -> onMasterSwitch(checked) }
        binding.saveButton.setOnClickListener { save() }
        binding.testButton.setOnClickListener { TestDialog.show(requireContext(), ::currentConfig) }
        binding.shizukuButton.setOnClickListener { requestShizukuPermission() }
        binding.uninstallButton.setOnClickListener { requestUninstall() }

        loadConfig()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onRefresh() {
        if (_binding == null) return
        loadConfig()
    }

    // ------------------------------------------------------------------

    private fun loadConfig() {
        val config = ConfigStore.load(requireContext())

        if (config.sentenceEndTrigger) binding.rbSentenceEnd.isChecked = true
        else binding.rbRealtime.isChecked = true

        binding.swAddMeow.isChecked = config.addMeow
        binding.swAddEmoticon.isChecked = config.addEmoticon
        binding.customEmoticonInput.setText(config.customEmoticons.joinToString("\n"))

        // 总开关：未授权无障碍时置灰，避免用户以为开了就生效
        val authorized = ServiceHelper.isAccessibilityEnabled(requireContext())
        binding.masterSwitch.isEnabled = authorized
        binding.masterSwitch.isChecked = authorized && config.enabled

        renderServiceStatus(authorized, config.enabled)
        renderShizukuStatus()
    }

    private fun renderServiceStatus(authorized: Boolean, enabled: Boolean) {
        val ctx = requireContext()
        if (!authorized) {
            binding.serviceCard.setBackgroundResource(R.drawable.bg_service_off)
            binding.serviceDot.setBackgroundResource(R.drawable.bg_dot_offline)
            binding.serviceTitle.text = ctx.getString(R.string.service_off_title)
            binding.serviceDesc.text = ctx.getString(R.string.service_off_desc)
            binding.serviceButton.text = ctx.getString(R.string.service_action_open)
            return
        }

        binding.serviceCard.setBackgroundResource(R.drawable.bg_service_on)
        binding.serviceDot.setBackgroundResource(R.drawable.bg_dot_online)
        binding.serviceButton.text = ctx.getString(R.string.service_action_settings)

        if (enabled) {
            binding.serviceTitle.text = ctx.getString(R.string.service_on_title)
            binding.serviceDesc.text = ctx.getString(R.string.service_on_desc)
        } else {
            binding.serviceTitle.text = ctx.getString(R.string.service_off_title)
            binding.serviceDesc.text = ctx.getString(R.string.master_switch_desc)
        }
    }

    private fun onServiceButtonClick() {
        ensureConsent {
            val host = activity as? MainActivity
            host?.expectReturnToControl()
            Toast.makeText(requireContext(), R.string.toast_find_in_list, Toast.LENGTH_LONG).show()
            if (!ServiceHelper.openAccessibilitySettings(requireContext())) {
                host?.cancelExpectedReturnToControl()
                Toast.makeText(requireContext(), R.string.toast_open_settings_failed, Toast.LENGTH_LONG).show()
            }
        }
    }

    /** 权限相关操作前再次确认用户已明确同意用途说明。 */
    private fun ensureConsent(onAccepted: () -> Unit) {
        val context = context ?: return
        val prefs = context.getSharedPreferences("privacy_consent", android.content.Context.MODE_PRIVATE)
        if (prefs.getBoolean("consent_accepted", false)) {
            onAccepted()
            return
        }
        AlertDialog.Builder(context)
            .setTitle(R.string.consent_title)
            .setMessage(R.string.consent_message)
            .setPositiveButton(R.string.consent_continue) { _, _ ->
                prefs.edit().putBoolean("consent_decided", true)
                    .putBoolean("consent_accepted", true).apply()
                onAccepted()
            }
            .setNegativeButton(R.string.consent_decline, null)
            .show()
    }


    private fun renderShizukuStatus() {
        val context = context ?: return
        binding.shizukuStatus.text = when {
            !Shizuku.pingBinder() -> getString(R.string.shizuku_not_running)
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED ->
                getString(R.string.shizuku_authorized)
            else -> getString(R.string.shizuku_not_authorized)
        }
    }

    private fun requestShizukuPermission() {
        ensureConsent { requestShizukuPermissionAfterConsent() }
    }

    private fun requestShizukuPermissionAfterConsent() {
        val context = context ?: return
        if (!Shizuku.pingBinder()) {
            AlertDialog.Builder(context)
                .setTitle(R.string.shizuku_title)
                .setMessage(R.string.shizuku_missing_message)
                .setPositiveButton(R.string.ok, null)
                .show()
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, R.string.shizuku_authorized, Toast.LENGTH_SHORT).show()
            renderShizukuStatus()
            return
        }
        (activity as? MainActivity)?.expectReturnToControl()
        Shizuku.addRequestPermissionResultListener(object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                if (requestCode != SHIZUKU_REQUEST_CODE) return
                Shizuku.removeRequestPermissionResultListener(this)
                if (!isAdded) return
                renderShizukuStatus()
                Toast.makeText(
                    requireContext(),
                    if (grantResult == PackageManager.PERMISSION_GRANTED) R.string.shizuku_authorized else R.string.shizuku_denied,
                    Toast.LENGTH_LONG
                ).show()
            }
        })
        Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
    }

    private fun requestUninstall() {
        val context = context ?: return
        AlertDialog.Builder(context)
            .setTitle(R.string.uninstall_title)
            .setMessage(R.string.uninstall_message)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.uninstall_action) { _, _ ->
                val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}"))
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(context, R.string.uninstall_failed, Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    companion object {
        private const val SHIZUKU_REQUEST_CODE = 4021
    }

    /** 一键总开关：只改应用层的 enabled，不需要重新授权 */
    private fun onMasterSwitch(checked: Boolean) {
        if (!ServiceHelper.isAccessibilityEnabled(requireContext())) {
            // 没授权就拨开关，弹提示并回滚
            binding.masterSwitch.isChecked = false
            Toast.makeText(requireContext(), R.string.toast_need_accessibility, Toast.LENGTH_LONG).show()
            onServiceButtonClick()
            return
        }

        val config = ConfigStore.load(requireContext()).copy(enabled = checked)
        ConfigStore.save(requireContext(), config)
        renderServiceStatus(true, checked)
        Toast.makeText(
            requireContext(),
            if (checked) R.string.toast_master_on else R.string.toast_master_off,
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun currentConfig(): MeowConfig = MeowConfig(
        sentenceEndTrigger = binding.rbSentenceEnd.isChecked,
        enabled = binding.masterSwitch.isChecked,
        addMeow = binding.swAddMeow.isChecked,
        addEmoticon = binding.swAddEmoticon.isChecked,
        // 规则与不变词在规则页维护，这里从存储读，保证测试面板反映真实配置
        rules = ConfigStore.load(requireContext()).rules,
        protectedWords = ConfigStore.load(requireContext()).protectedWords,
        customEmoticons = parseEmoticons()
    )

    private fun parseEmoticons(): List<String> =
        binding.customEmoticonInput.text.toString()
            .split('\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    private fun save() {
        val stored = ConfigStore.load(requireContext())
        val updated = stored.copy(
            sentenceEndTrigger = binding.rbSentenceEnd.isChecked,
            enabled = if (binding.masterSwitch.isEnabled) binding.masterSwitch.isChecked else stored.enabled,
            addMeow = binding.swAddMeow.isChecked,
            addEmoticon = binding.swAddEmoticon.isChecked,
            customEmoticons = parseEmoticons()
        )
        ConfigStore.save(requireContext(), updated)
        Toast.makeText(requireContext(), R.string.toast_saved, Toast.LENGTH_SHORT).show()
    }
}

/**
 * 测试面板：输入原文，实时预览改写结果。
 *
 * 读的是界面上的**即时配置**，不要求先点保存。
 * 预览走完整改写（含颜文字），且不受触发模式影响——直接对整段文本处理。
 */
object TestDialog {
    fun show(context: android.content.Context, configProvider: () -> MeowConfig) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_test, null)
        val input = view.findViewById<android.widget.EditText>(R.id.test_input)
        val output = view.findViewById<android.widget.TextView>(R.id.test_output)

        val placeholder = context.getString(R.string.test_placeholder)

        fun preview() {
            val source = input.text.toString()
            output.text = if (source.isEmpty()) {
                placeholder
            } else {
                MeowTextProcessor.process(source, configProvider())
            }
        }

        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { preview() }
        })

        input.setText(context.getString(R.string.test_default_input))
        preview()

        AlertDialog.Builder(context)
            .setTitle(R.string.test_dialog_title)
            .setView(view)
            .setPositiveButton(R.string.test_copy) { _, _ ->
                val text = output.text.toString()
                if (text.isNotEmpty() && text != placeholder) {
                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                            as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("meow", text))
                    Toast.makeText(context, R.string.toast_copied, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.test_close, null)
            .show()
    }
}
