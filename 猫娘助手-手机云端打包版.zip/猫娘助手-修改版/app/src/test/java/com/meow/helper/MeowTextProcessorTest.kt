package com.meow.helper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * 核心改写逻辑的单元测试。
 *
 * 重点验证五件事：
 * 1. 标点前加喵 + 句末触发
 * 2. 规则引擎：我/你/人/了 + 用户自定义，且**无级联污染**
 * 3. 不变词：受保护区不改写，且抑制紧跟其后的「喵」
 * 4. 幂等性：重复处理不会叠加
 * 5. 边界：数字里的小数点 / 时间冒号
 */
class MeowTextProcessorTest {

    /** 只开加喵，规则全关，方便逐字断言 */
    private val meowOnly = MeowConfig(
        addMeow = true,
        addEmoticon = false,
        rules = emptyList(),
        protectedWords = emptyList()
    )

    /** 内置规则全开（我→本喵、你→主人、人→两脚兽、了→惹），不含颜文字 */
    private val builtInRules = meowOnly.copy(
        rules = MeowRule.defaults(),
        protectedWords = MeowRule.defaultProtectedWords()
    )

    /** 全开：内置规则 + 颜文字 */
    private val allOn = builtInRules.copy(addEmoticon = true)

    // ================================================================
    // 一、标点前加喵
    // ================================================================

    @Test
    fun `示例_你好你是谁_应在每个标点前加喵`() {
        assertEquals("你好喵，你是谁喵？", MeowTextProcessor.transform("你好，你是谁？", meowOnly))
    }

    @Test
    fun `中英文标点都应触发加喵`() {
        assertEquals("吃饭了喵。", MeowTextProcessor.transform("吃饭了。", meowOnly))
        assertEquals("好棒喵！", MeowTextProcessor.transform("好棒！", meowOnly))
        assertEquals("真的喵？", MeowTextProcessor.transform("真的？", meowOnly))
        assertEquals("苹果喵、香蕉喵。", MeowTextProcessor.transform("苹果、香蕉。", meowOnly))
        assertEquals("嗯喵,好的喵.", MeowTextProcessor.transform("嗯,好的.", meowOnly))
    }

    @Test
    fun `没有标点的文本不加喵`() {
        assertEquals("今天天气不错", MeowTextProcessor.transform("今天天气不错", meowOnly))
    }

    // ================================================================
    // 二、句末触发判定
    // ================================================================

    @Test
    fun `逗号顿号分号冒号不触发_句末标点才触发`() {
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("你好，"))
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("苹果、"))
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("等等；"))
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("注意："))
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("你好"))
        assertFalse(MeowTextProcessor.endsWithSentenceEnd(""))

        assertTrue(MeowTextProcessor.endsWithSentenceEnd("你好。"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("你好！"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("你好？"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("你好…"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("hi!"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("hi?"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("你好。  "))
    }

    @Test
    fun `句末触发下小数点不算句子结束`() {
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("版本 1.2"))
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("圆周率 3.14"))
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("圆周率是 3.14。"))
    }

    @Test
    fun `标点触发判定仍保留`() {
        assertTrue(MeowTextProcessor.endsWithPunctuation("你好，"))
        assertFalse(MeowTextProcessor.endsWithPunctuation("你好"))
    }

    @Test
    fun `用户需求_逗号时不动手_句号时整句一起处理`() {
        // 打到「你好，」——句末触发模式下不处理
        assertFalse(MeowTextProcessor.endsWithSentenceEnd("你好，"))
        // 打到「你好，你好。」——整句一次性改写
        assertTrue(MeowTextProcessor.endsWithSentenceEnd("你好，你好。"))
        assertEquals("你好喵，你好喵。", MeowTextProcessor.transform("你好，你好。", meowOnly))
    }

    // ================================================================
    // 三、规则引擎
    // ================================================================

    @Test
    fun `四条内置规则都应生效`() {
        assertEquals("本喵吃惹喵。", MeowTextProcessor.transform("我吃了。", builtInRules))
        assertEquals("主人好喵。", MeowTextProcessor.transform("你好。", builtInRules))
        assertEquals("两脚兽喵。", MeowTextProcessor.transform("人。", builtInRules))
    }

    @Test
    fun `无级联污染_你换成主人后_主人里的人不再被换成两脚兽`() {
        // 单趟扫描原文，替换产物不会被再次扫描，这是本实现的核心性质
        assertEquals("主人好喵。", MeowTextProcessor.transform("你好。", builtInRules))
        assertFalse(
            "不应出现「主两脚兽」",
            MeowTextProcessor.transform("你好。", builtInRules).contains("主两脚兽")
        )
    }

    @Test
    fun `原文里独立的人字仍应换成两脚兽`() {
        assertEquals("本喵是两脚兽喵。", MeowTextProcessor.transform("我是人。", builtInRules))
        assertEquals("好多两脚兽喵。", MeowTextProcessor.transform("好多人。", builtInRules))
    }

    @Test
    fun `了换成惹`() {
        assertEquals("太好惹喵！", MeowTextProcessor.transform("太好了！", builtInRules))
        assertEquals("本喵知道惹喵。", MeowTextProcessor.transform("我知道了。", builtInRules))
    }

    @Test
    fun `长词优先匹配`() {
        val rules = listOf(
            MeowRule("我们", "本喵们"),
            MeowRule("我", "本喵")
        )
        val cfg = meowOnly.copy(rules = rules)
        // 「我们」应整体命中长规则，而不是先被「我」抢走
        assertEquals("本喵们走喵。", MeowTextProcessor.transform("我们走。", cfg))
    }

    @Test
    fun `用户自定义规则生效且优先于内置`() {
        val userRules = listOf(MeowRule("你", "姐姐", enabled = true, builtIn = false))
        val cfg = meowOnly.copy(rules = userRules + MeowRule.defaults())
        assertEquals("姐姐好喵。", MeowTextProcessor.transform("你好。", cfg))
    }

    @Test
    fun `关闭的规则不参与改写`() {
        val rules = MeowRule.defaults().map {
            if (it.from == "人") it.copy(enabled = false) else it
        }
        val cfg = builtInRules.copy(rules = rules)
        assertEquals("本喵是人喵。", MeowTextProcessor.transform("我是人。", cfg))
    }

    @Test
    fun `替换为空等于删除该词`() {
        val cfg = meowOnly.copy(rules = listOf(MeowRule("哈哈", "")))
        assertEquals("好笑喵。", MeowTextProcessor.transform("哈哈好笑。", cfg))
    }

    @Test
    fun `自己换自己的规则被忽略`() {
        // from == to 的规则应被 isActive() 过滤掉，不参与匹配
        val cfg = meowOnly.copy(rules = listOf(MeowRule("哈", "哈")))
        assertEquals("哈哈喵，好喵。", MeowTextProcessor.transform("哈哈，好。", cfg))
        assertEquals(listOf<MeowRule>(), cfg.activeRules())
    }

    @Test
    fun `标点前已是喵时不再插入_保证幂等`() {
        // 这条同时解释了上面为什么不能用「喵。」来验证：幂等保护会先生效
        assertEquals("喵。", MeowTextProcessor.transform("喵。", meowOnly))
        assertEquals("喵喵。", MeowTextProcessor.transform("喵喵。", meowOnly))
    }

    // ================================================================
    // 四、不变词
    // ================================================================

    @Test
    fun `用户需求_本喵们登记为不变词后不再被追加喵`() {
        val cfg = meowOnly.copy(protectedWords = listOf("本喵们"))
        // 未登记时：「本喵们，」会变成「本喵们喵，」
        assertEquals("本喵们喵，", MeowTextProcessor.transform("本喵们，", meowOnly))
        // 登记后：保持原样
        assertEquals("本喵们，", MeowTextProcessor.transform("本喵们，", cfg))
    }

    @Test
    fun `不变词内部不被任何规则改写`() {
        // 「我们」被保护，则其中的「我」不再换成「本喵」
        val cfg = meowOnly.copy(
            rules = MeowRule.defaults(),
            protectedWords = MeowRule.defaultProtectedWords() + "我们"
        )
        assertEquals("我们和主人都好喵。", MeowTextProcessor.transform("我们和你都好。", cfg))
    }

    @Test
    fun `不变词长词优先`() {
        val cfg = meowOnly.copy(protectedWords = listOf("本喵", "本喵们"))
        // 应整体保护「本喵们」，因此后面的逗号不加喵
        assertEquals("本喵们，", MeowTextProcessor.transform("本喵们，", cfg))
    }

    @Test
    fun `内置不变词保证主人不被拆成主两脚兽`() {
        // 第一次改写
        val once = MeowTextProcessor.transform("你好了。", builtInRules)
        assertEquals("主人好惹喵。", once)
        // 第二次处理同一段文本：「主人」受保护，不会变成「主两脚兽」
        assertEquals(once, MeowTextProcessor.transform(once, builtInRules))
    }

    @Test
    fun `不变词抑制喵_但不影响后续其他标点`() {
        val cfg = meowOnly.copy(protectedWords = listOf("本喵们"))
        assertEquals("本喵们，吃饭喵。", MeowTextProcessor.transform("本喵们，吃饭。", cfg))
    }

    // ================================================================
    // 五、幂等性
    // ================================================================

    @Test
    fun `重复处理不应叠加喵`() {
        val once = MeowTextProcessor.transform("你好，你是谁？", meowOnly)
        val twice = MeowTextProcessor.transform(once, meowOnly)
        val thrice = MeowTextProcessor.transform(twice, meowOnly)
        assertEquals(once, twice)
        assertEquals(twice, thrice)
    }

    @Test
    fun `全规则全开下连续处理三轮结果稳定`() {
        val once = MeowTextProcessor.transform("你好，我是人，你吃了吗？", builtInRules)
        assertEquals("主人好喵，本喵是两脚兽喵，主人吃惹吗喵？", once)
        assertEquals(once, MeowTextProcessor.transform(once, builtInRules))
        assertEquals(once, MeowTextProcessor.transform(MeowTextProcessor.transform(once, builtInRules), builtInRules))
    }

    @Test
    fun `连续多句_第二句处理时不破坏第一句`() {
        val first = MeowTextProcessor.transform("你好，你好。", meowOnly)
        assertEquals("你好喵，你好喵。", first)
        assertEquals("你好喵，你好喵。吃饭了吗喵？", MeowTextProcessor.transform(first + "吃饭了吗？", meowOnly))
    }

    // ================================================================
    // 六、颜文字
    // ================================================================

    @Test
    fun `全开时应在末尾追加颜文字`() {
        val out = MeowTextProcessor.process("你好，我是人。", allOn, Random(42))
        val pool = allOn.emoticonPool()
        assertTrue("末尾应命中颜文字库，实际：$out", pool.any { out.endsWith(it) })
        val body = pool.first { out.endsWith(it) }.let { out.removeSuffix(it) }
        assertEquals("主人好喵，本喵是两脚兽喵。", body)
    }

    @Test
    fun `自定义颜文字优先于内置库`() {
        val cfg = allOn.copy(customEmoticons = listOf("(=^ω^=)"))
        assertEquals("(=^ω^=)", cfg.randomEmoticon())
    }

    @Test
    fun `自定义库为空或全空白时回落到内置库`() {
        val cfg = allOn.copy(customEmoticons = listOf("", "   "))
        assertEquals(MeowConfig.BUILT_IN_EMOTICONS, cfg.emoticonPool())
    }

    @Test
    fun `剥离颜文字_即使用户在其后继续打字`() {
        assertEquals(
            "你好喵，本喵在",
            MeowTextProcessor.stripTrailingEmoticon("你好喵，❍⩊❍本喵在", "❍⩊❍")
        )
    }

    @Test
    fun `剥离颜文字_没有命中时原样返回`() {
        assertEquals("你好喵，", MeowTextProcessor.stripTrailingEmoticon("你好喵，", "❍⩊❍"))
        assertEquals("你好喵，", MeowTextProcessor.stripTrailingEmoticon("你好喵，", null))
    }

    // ================================================================
    // 七、边界
    // ================================================================

    @Test
    fun `小数点和时间冒号不加喵`() {
        assertEquals("圆周率是3.14喵。", MeowTextProcessor.transform("圆周率是3.14。", meowOnly))
        assertEquals("12:30开会喵。", MeowTextProcessor.transform("12:30开会。", meowOnly))
    }

    @Test
    fun `非数字语境的半角点号仍加喵`() {
        assertEquals("ok喵. 好的喵.", MeowTextProcessor.transform("ok. 好的.", meowOnly))
    }

    @Test
    fun `空文本安全`() {
        assertEquals("", MeowTextProcessor.transform("", allOn))
        assertEquals("", MeowTextProcessor.process("", allOn))
    }

    @Test
    fun `关掉加喵后只跑规则`() {
        val cfg = builtInRules.copy(addMeow = false)
        assertEquals("本喵是两脚兽。", MeowTextProcessor.transform("我是人。", cfg))
    }

    // ================================================================
    // 八、配置合并
    // ================================================================

    @Test
    fun `withMergedBuiltIns_保留用户对内置规则的开关选择`() {
        val userTuned = MeowRule.defaults().map {
            if (it.from == "了") it.copy(enabled = false) else it
        }
        val merged = MeowConfig(rules = userTuned).withMergedBuiltIns()
        assertFalse(merged.rules.first { it.from == "了" }.enabled)
        assertTrue(merged.rules.first { it.from == "我" }.enabled)
    }

    @Test
    fun `withMergedBuiltIns_用户规则排在前且内置规则补齐`() {
        val onlyUser = listOf(MeowRule("笨蛋", "小笨蛋", builtIn = false))
        val merged = MeowConfig(rules = onlyUser).withMergedBuiltIns()
        assertEquals("笨蛋", merged.rules.first().from)
        assertFalse(merged.rules.first().builtIn)
        // 内置四条应全部补齐
        assertEquals(4, merged.rules.count { it.builtIn })
    }

    @Test
    fun `activeRules_过滤掉关闭与自我替换的规则`() {
        val cfg = MeowConfig(
            rules = listOf(
                MeowRule("我", "本喵", enabled = true),
                MeowRule("你", "主人", enabled = false),
                MeowRule("", "空"),
                MeowRule("喵", "喵")
            )
        )
        assertEquals(listOf("我"), cfg.activeRules().map { it.from })
    }

    @Test
    fun `activeProtectedWords_去空白去重`() {
        val cfg = MeowConfig(protectedWords = listOf(" 本喵 ", "", "本喵", "主人"))
        assertEquals(listOf("本喵", "主人"), cfg.activeProtectedWords())
    }
}
